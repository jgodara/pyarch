from flask import Flask

app = Flask(__name__, static_folder="frontend", static_url_path="/frontend")


@app.route('/')
def root_controller():
    """
    Root Controller: Renders the front-end
    :return: The index.html page containing the React front
    """
    return app.send_static_file('index.html')


if __name__ == '__main__':
    app.run(port=8000)